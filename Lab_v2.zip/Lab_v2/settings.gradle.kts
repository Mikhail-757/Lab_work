pluginManagement {
    repositories {
        gradlePluginPortal()
        mavenCentral()
    }
}

rootProject.name = "gradle-lab"

include("string-utils")

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
