package org.example;

import org.example.utils.StringProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Scanner;

public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        logger.info("Start");

        loadBuildPassport();

        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите строку: ");
        String input = scanner.nextLine();

        if (input == null || input.isEmpty()) {
            logger.info("Введена пустая строка или null");
            System.out.println("Строка пуста!");
        } else {
            String reversed = StringProcessor.reverse(input);
            String capitalized = StringProcessor.capitalize(input);
            String swapped = StringProcessor.swapCase(input);
            String truncated = StringProcessor.truncate(input, 20);

            logger.info("Reversed: {}", reversed);
            logger.info("Capitalized: {}", capitalized);
            logger.info("SwapCase: {}", swapped);
            logger.info("Truncated: {}", truncated);

            System.out.println("Реверс: " + reversed);
            System.out.println("С заглавной: " + capitalized);
            System.out.println("Смена регистра: " + swapped);
            System.out.println("Обрезка: " + truncated);
        }

        scanner.close();
        logger.info("Finish");
    }

    private static void loadBuildPassport() {
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("build-passport.properties")) {
            if (is != null) {
                Properties props = new Properties();
                props.load(is);
                logger.info("=== Build Passport ===");
                logger.info("User: {}", props.getProperty("build.user"));
                logger.info("OS: {}", props.getProperty("os.name"));
                logger.info("Java: {}", props.getProperty("java.version"));
                logger.info("Timestamp: {}", props.getProperty("build.timestamp"));
                logger.info("Build Number: {}", props.getProperty("build.number"));
                logger.info("Git Hash: {}", props.getProperty("git.commit.hash"));
                logger.info("Greeting: {}", props.getProperty("greeting"));
                logger.info("=====================");
            } else {
                logger.warn("build-passport.properties not found");
            }
        } catch (IOException e) {
            logger.error("Error reading build-passport.properties", e);
        }
    }
}
