import java.util.Properties
import java.time.LocalDateTime
import java.io.FileWriter

plugins {
    id("java")
    application
    id("com.gradleup.shadow") version "9.4.2"
}

group = "org.example"
version = "1.0-SNAPSHOT"

application {
    mainClass.set("org.example.Main")
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.apache.commons:commons-lang3:3.14.0")
    implementation("org.slf4j:slf4j-api:2.0.11")
    implementation("ch.qos.logback:logback-classic:1.4.14")
    implementation(project(":string-utils"))

    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")
}

tasks.test {
    useJUnitPlatform()
}

tasks.shadowJar {
    manifest {
        attributes(Pair("Main-Class", "org.example.Main"))
    }
}

abstract class PrintInfoTask : DefaultTask() {

    @TaskAction
    fun print() {
        println("======================================")
        println("Это моя первая пользовательская задача!")
        println("Проект: ${project.name}")
        println("Версия Gradle: ${project.gradle.gradleVersion}")
        println("======================================")
    }
}

tasks.register<PrintInfoTask>("printInfo") {
    group = "Custom"
    description = "Выводит информацию о проекте"
}

abstract class GenerateBuildInfoTask : DefaultTask() {

    @get:Input
    abstract val gitCommitHash: Property<String>

    @TaskAction
    fun generate() {
        val resourcesDir = project.file("src/main/resources")
        if (!resourcesDir.exists()) {
            resourcesDir.mkdirs()
        }

        val propertiesFile = project.file("src/main/resources/build-passport.properties")
        val props = Properties()

        props["build.user"] = System.getenv("USERNAME") ?: System.getenv("USER") ?: "unknown"
        props["os.name"] = System.getProperty("os.name")
        props["java.version"] = System.getProperty("java.version")
        props["build.timestamp"] = LocalDateTime.now().toString()
        props["greeting"] = "Hello from Gradle Build!"

        val commitHash = gitCommitHash.orNull ?: "N/A"
        props["git.commit.hash"] = commitHash

        val buildNumberFile = project.file("build-number.txt")
        var buildNumber = 1
        if (buildNumberFile.exists()) {
            buildNumber = buildNumberFile.readText().trim().toIntOrNull() ?: 1
        }
        buildNumber++
        buildNumberFile.writeText(buildNumber.toString())
        props["build.number"] = buildNumber.toString()

        val writer = FileWriter(propertiesFile)
        props.store(writer, "Build Passport")
        writer.close()

        println("Build passport generated: ${propertiesFile.absolutePath}")
        println("Build number: $buildNumber")
        println("Git commit hash: $commitHash")
    }
}

tasks.register<GenerateBuildInfoTask>("generateBuildInfo") {
    group = "Custom"
    description = "Генерирует build-passport.properties"

    val gitResult = providers.exec {
        commandLine("git", "rev-parse", "HEAD")
    }
    gitCommitHash.set(
        gitResult.standardOutput.asText.map { it.trim() }
            .orElse("N/A")
    )
}

tasks.named("processResources") {
    dependsOn(tasks.named("generateBuildInfo"))
}
