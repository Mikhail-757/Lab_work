package org.example.utils;

import org.apache.commons.lang3.StringUtils;

public class StringProcessor {

    public static String reverse(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return StringUtils.reverse(input);
    }

    public static String capitalize(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return StringUtils.capitalize(input);
    }

    public static String swapCase(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return StringUtils.swapCase(input);
    }

    public static String truncate(String input, int maxWidth) {
        if (input == null) {
            return null;
        }
        return StringUtils.abbreviate(input, maxWidth);
    }
}
