# Лабораторная работа: Инструмент сборки Gradle

## Описание

Проект демонстрирует работу с системой сборки Gradle на примере Java-приложения для обработки строк.

## Стек

- **Java 25** (Temurin)
- **Gradle 9.5.1** (Kotlin DSL)
- **Apache Commons Lang3** — утилиты для строк
- **SLF4J + Logback** — логирование
- **Shadow Plugin** — сборка Fat JAR

## Структура проекта

```
├── build.gradle.kts              # Конфигурация сборки
├── settings.gradle.kts           # Настройки многомодульности
├── gradlew / gradlew.bat         # Gradle Wrapper
├── src/main/java/org/example/
│   └── Main.java                 # Точка входа
├── src/main/resources/           # Ресурсы
├── string-utils/                 # Модуль обработки строк
│   ├── build.gradle.kts
│   └── src/main/java/org/example/utils/
│       └── StringProcessor.java  # Утилиты для строк
└── .gitignore
```

## Выполненные задания

| # | Задание | Статус |
|---|---------|--------|
| 1 | Создание Gradle-проекта, плагин application | ✅ |
| 2 | Зависимости: Commons Lang3, SLF4J, Logback | ✅ |
| 3 | Main.java с логированием и обработкой строк | ✅ |
| 4 | Fat JAR через Shadow Plugin | ✅ |
| 5 | Кастомные задачи: printInfo, generateBuildInfo | ✅ |
| 6 | Многомодульная структура (string-utils) | ✅ |
| 7 | Git-хеш и инкремент номера сборки | ✅ |

## Требования

- JDK 17+
- VS Code с расширениями:
  - **Extension Pack for Java**
  - **Gradle for Java**

## Команды

### Сборка и запуск

```bash
# Полная сборка
.\gradlew clean build

# Запуск приложения
.\gradlew run

# Сборка Fat JAR
.\gradlew shadowJar

# Запуск Fat JAR
java -jar build/libs/gradle-lab-1.0-SNAPSHOT-all.jar
```

### Кастомные задачи

```bash
# Информация о проекте
.\gradlew printInfo

# Генерация build-passport.properties
.\gradlew generateBuildInfo
```

## Что делает приложение

1. При старте читает `build-passport.properties` (пользователь, ОС, Java, timestamp, git-хеш, номер сборки)
2. Запрашивает ввод строки
3. Применяет операции через `StringProcessor`:
   - **reverse** — реверс строки
   - **capitalize** — первая буква заглавная
   - **swapCase** — смена регистра
   - **truncate** — обрезка до 20 символов
4. Выводит результаты через логгер Logback

## Build Passport

Файл `build-passport.properties` генерируется автоматически при каждой сборке и содержит:

| Ключ | Описание |
|------|----------|
| `build.user` | Имя пользователя |
| `os.name` | Операционная система |
| `java.version` | Версия Java |
| `build.timestamp` | Дата и время сборки |
| `build.number` | Инкрементируемый номер сборки |
| `git.commit.hash` | Хеш последнего коммита |
| `greeting` | Приветственное сообщение |

## Настройка VS Code

1. Откройте папку проекта в VS Code
2. Установите расширения:
   - `vscjava.vscode-java-pack`
   - `naco-siren.gradle-language`
3. Gradle wrapper автоматически распознается — задачи доступны через палитру команд (`Ctrl+Shift+P` → `Gradle: Show tasks`)
