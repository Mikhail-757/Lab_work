package org.example.service;

import org.example.repository.NotificationRepository;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationServiceNotFoundTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private NotificationService notificationService;

    @Test
    @DisplayName("getNotificationById должен бросать NoSuchElementException, когда уведомление не найдено")
    void shouldThrowWhenNotificationNotFoundById() {
        Long missingId = 404L;
        when(notificationRepository.findById(missingId)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class,
                () -> notificationService.getNotificationById(missingId));

        verify(notificationRepository, times(1)).findById(missingId);
        verify(notificationRepository, never()).delete(any());
    }

    @Test
    @DisplayName("Исключение должно выбрасываться для любого несуществующего id")
    void shouldThrowForAnyMissingId() {
        when(notificationRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(1L));
        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(999L));
        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(-1L));

        verify(notificationRepository, times(3)).findById(any());
    }
}
