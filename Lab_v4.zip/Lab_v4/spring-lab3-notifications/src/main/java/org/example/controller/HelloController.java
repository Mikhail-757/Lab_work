package org.example.controller; // об п

import org.springframework.web.bind.annotation.GetMapping; //обр гет з
import org.springframework.web.bind.annotation.RequestParam; //пол пар из урл
import org.springframework.web.bind.annotation.RestController; //к

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String sayHello() {
        return "Привет, Spring Boot!";
    }
    
    @GetMapping("/goodbye")
    public String sayGoodbye() {  
        return "ПОка, Spring Boot!";
    }
    
    @GetMapping("/greet") 
    public String greet(@RequestParam String name) {  
        return "привет !!, " + name + "!";  
    }
}