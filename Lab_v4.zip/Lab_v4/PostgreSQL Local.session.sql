CREATE DATABASE spring_lab3_notifications;

