package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        logger.info("Hello from Maven project with logging!");

        Person person = new Person("Иван", "Иванов", 25);
        logger.info("Created person: {}", person);

        String json = JsonUtils.toJson(person);
        logger.info("Serialized to JSON: {}", json);

        Person deserialized = JsonUtils.fromJson(json, Person.class);
        logger.info("Deserialized from JSON: {}", deserialized);
    }
}
