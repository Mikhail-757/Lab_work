# Лабораторная 6 — Задание 3: Unit-тест для `getNotificationById()`

## Цель
Реализовать unit-тест для метода `NotificationService.getNotificationById(Long id)` с использованием JUnit 5 и Mockito.

## Исходный код метода

`src/main/java/org/example/service/NotificationService.java:43-45`

```java
public Notification getNotificationById(Long id) {
    return notificationRepository.findById(id).orElseThrow();
}
```

При отсутствии уведомления `Optional.orElseThrow()` выбрасывает `NoSuchElementException`.

## Реализация теста

`src/test/java/org/example/service/NotificationServiceGetByIdTest.java`

```java
package org.example.service;

import org.example.model.entity.Notification;
import org.example.model.entity.User;
import org.example.model.enums.NotificationChannel;
import org.example.model.enums.NotificationStatus;
import org.example.repository.NotificationRepository;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationServiceGetByIdTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private NotificationService notificationService;

    @Test
    void shouldReturnNotificationById() {
        User recipient = new User();
        recipient.setId(1L);
        recipient.setName("Иван Иванов");

        Notification notification = new Notification();
        notification.setId(10L);
        notification.setTitle("Напоминание");
        notification.setMessage("Завтра пара по Spring");
        notification.setChannel(NotificationChannel.EMAIL);
        notification.setStatus(NotificationStatus.CREATED);
        notification.setRecipient(recipient);

        when(notificationRepository.findById(10L)).thenReturn(Optional.of(notification));

        Notification result = notificationService.getNotificationById(10L);

        assertNotNull(result);
        assertEquals(10L, result.getId());
        assertEquals("Напоминание", result.getTitle());
        assertEquals("Завтра пара по Spring", result.getMessage());
        assertEquals(NotificationChannel.EMAIL, result.getChannel());
        assertEquals(NotificationStatus.CREATED, result.getStatus());
        assertEquals(recipient, result.getRecipient());

        verify(notificationRepository, times(1)).findById(10L);
    }

    @Test
    void shouldThrowWhenNotificationNotFound() {
        when(notificationRepository.findById(404L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(404L));

        verify(notificationRepository, times(1)).findById(404L);
    }
}
```

## Что здесь используется

| Элемент | Назначение |
|---|---|
| `@ExtendWith(MockitoExtension.class)` | Подключает Mockito к JUnit 5 |
| `@Mock` для двух репозиториев | `NotificationService` зависит от обоих — мокируем, чтобы не зависеть от БД |
| `@InjectMocks` | Создаёт `NotificationService` с внедрёнными mock-объектами |
| `when(...).thenReturn(...)` | Стаб `findById` для позитивного и негативного сценариев |
| `assertEquals` | Проверка всех значимых полей сущности (включая связь с `recipient`) |
| `assertThrows` | Проверка выброса `NoSuchElementException` при отсутствии уведомления |
| `verify(..., times(1))` | Подтверждение количества вызовов `findById` |

## Покрытие сценариев

1. **Позитивный** `shouldReturnNotificationById()` — уведомление найдено: проверяется, что сервис возвращает сущность со всеми корректными полями (включая `recipient`), и `findById` вызван ровно один раз.
2. **Негативный** `shouldThrowWhenNotificationNotFound()` — уведомление не найдено: проверяется выброс `NoSuchElementException` и обращение к репозиторию.

## Зависимости

`Notification` импортируется из `org.example.model.entity`, перечисления — из `org.example.model.enums`. Все классы присутствуют в основном проекте.

## Как запустить

Скопируйте файл в `spring-lab3-notifications/src/test/java/org/example/service/` и выполните:

```bash
mvn test -Dtest=NotificationServiceGetByIdTest
```
