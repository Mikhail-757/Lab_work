# Лабораторная 6 — Задание 1: Unit-тест для `getUserById()`

## Цель
Написать unit-тест для метода `UserService.getUserById(Long id)` с использованием JUnit 5 и Mockito.

## Исходный код метода

`src/main/java/org/example/service/UserService.java:33-35`

```java
public User getUserById(Long id) {
    return userRepository.findById(id).orElseThrow();
}
```

Метод делегирует поиск в `UserRepository`. При отсутствии пользователя `Optional.orElseThrow()` выбрасывает `NoSuchElementException`.

## Реализация теста

`src/test/java/org/example/service/UserServiceGetUserByIdTest.java`

```java
package org.example.service;

import org.example.model.entity.User;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceGetUserByIdTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void shouldReturnUserById() {
        User user = new User();
        user.setId(1L);
        user.setName("Иван Иванов");
        user.setEmail("ivan@example.com");
        user.setPhone("+79990001122");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        User result = userService.getUserById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Иван Иванов", result.getName());
        assertEquals("ivan@example.com", result.getEmail());
        verify(userRepository, times(1)).findById(1L);
    }

    @Test
    void shouldThrowWhenUserNotFound() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> userService.getUserById(99L));
        verify(userRepository, times(1)).findById(99L);
    }
}
```

## Что здесь используется

| Элемент | Назначение |
|---|---|
| `@ExtendWith(MockitoExtension.class)` | Подключает Mockito к JUnit 5 |
| `@Mock` | Создаёт mock-объект `UserRepository` без реальной БД |
| `@InjectMocks` | Создаёт `UserService` и внедряет в него mock-репозиторий |
| `when(...).thenReturn(...)` | Описывает поведение mock-объекта (stub) |
| `assertNotNull` / `assertEquals` | Проверка полей возвращённого пользователя |
| `assertThrows` | Проверка негативного сценария — пользователь не найден |
| `verify(..., times(1))` | Явная проверка количества вызовов `findById` |

## Покрытие сценариев

1. **Позитивный** `shouldReturnUserById()` — пользователь найден: проверяется, что сервис возвращает объект `User` с корректными полями и ровно один раз обращается к `userRepository.findById(1L)`.
2. **Негативный** `shouldThrowWhenUserNotFound()` — пользователь не найден: проверяется, что выбрасывается `NoSuchElementException`, и репозиторий был вызван.

## Зависимости

Используется `spring-boot-starter-test` из `pom.xml` проекта `spring-lab3-notifications`, в состав которого входят JUnit 5 и Mockito. Дополнительно подключать ничего не нужно.

## Как запустить

Тест-файл лежит в Maven-структуре `src/test/java`. Для запуска его нужно скопировать в проект `spring-lab3-notifications` по тому же пути (`src/test/java/org/example/service/`) и выполнить:

```bash
mvn test -Dtest=UserServiceGetUserByIdTest
```

либо запустить класс через зелёную стрелку в IntelliJ IDEA.
