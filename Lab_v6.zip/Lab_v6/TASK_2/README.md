# Лабораторная 6 — Задание 2: Unit-тест для `deleteUser()`

## Цель
Написать unit-тест для метода `UserService.deleteUser(Long id)` и убедиться, что при удалении вызывается `userRepository.delete(...)`.

## Исходный код метода

`src/main/java/org/example/service/UserService.java:47-50`

```java
public void deleteUser(Long id) {
    User user = userRepository.findById(id).orElseThrow();
    userRepository.delete(user);
}
```

Метод сначала ищет пользователя по `id`, а затем удаляет найденную сущность через репозиторий. Если пользователь не найден, `orElseThrow()` выбрасывает `NoSuchElementException` и `delete()` не вызывается.

## Реализация теста

`src/test/java/org/example/service/UserServiceDeleteUserTest.java`

```java
package org.example.service;

import org.example.model.entity.User;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceDeleteUserTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void shouldDeleteUser() {
        User user = new User();
        user.setId(1L);
        user.setName("Иван Иванов");
        user.setEmail("ivan@example.com");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        userService.deleteUser(1L);

        verify(userRepository, times(1)).findById(1L);
        verify(userRepository, times(1)).delete(user);
    }

    @Test
    void shouldThrowWhenDeletingNonExistingUser() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> userService.deleteUser(99L));

        verify(userRepository, times(1)).findById(99L);
        verify(userRepository, never()).delete(org.mockito.ArgumentMatchers.any(User.class));
    }
}
```

## Что здесь используется

| Элемент | Назначение |
|---|---|
| `@ExtendWith(MockitoExtension.class)` | Подключает Mockito к JUnit 5 |
| `@Mock` | Создаёт mock-объект `UserRepository` |
| `@InjectMocks` | Создаёт `UserService` и внедряет в него mock-репозиторий |
| `when(...).thenReturn(...)` | Стаб `findById` для возврата нужного `User` или пустого `Optional` |
| `verify(..., times(1))` | Проверка, что `findById` и `delete` вызваны ровно один раз |
| `verify(..., never())` | Проверка, что `delete` НЕ был вызван при отсутствии пользователя |
| `assertThrows` | Проверка, что при отсутствии пользователя выбрасывается `NoSuchElementException` |

## Покрытие сценариев

1. **Позитивный** `shouldDeleteUser()` — пользователь найден: проверяется, что `findById(1L)` вызван 1 раз и `delete(user)` вызван 1 раз.
2. **Негативный** `shouldThrowWhenDeletingNonExistingUser()` — пользователь не найден: проверяется выброс `NoSuchElementException` и то, что `delete(...)` НЕ вызывался (`never()`).

## Зависимости

`spring-boot-starter-test` уже подключён в `pom.xml`. Дополнительных зависимостей не требуется.

## Как запустить

Скопируйте файл в проект `spring-lab3-notifications` по пути `src/test/java/org/example/service/` и выполните:

```bash
mvn test -Dtest=UserServiceDeleteUserTest
```
