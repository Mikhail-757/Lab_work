# Лабораторная 6 — Задание 4: Негативный тест — уведомление не найдено

## Цель
Добавить отдельный негативный unit-тест для сценария, когда уведомление не найдено в `NotificationService.getNotificationById()`.

## Исходный код метода

`src/main/java/org/example/service/NotificationService.java:43-45`

```java
public Notification getNotificationById(Long id) {
    return notificationRepository.findById(id).orElseThrow();
}
```

При отсутствии записи в БД `Optional.orElseThrow()` выбрасывает `NoSuchElementException`. Негативный тест должен зафиксировать это поведение и убедиться, что метод не возвращает `null` и не «проглатывает» ошибку.

## Реализация теста

`src/test/java/org/example/service/NotificationServiceNotFoundTest.java`

```java
package org.example.service;

import org.example.repository.NotificationRepository;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationServiceNotFoundTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private NotificationService notificationService;

    @Test
    @DisplayName("getNotificationById должен бросать NoSuchElementException, когда уведомление не найдено")
    void shouldThrowWhenNotificationNotFoundById() {
        Long missingId = 404L;
        when(notificationRepository.findById(missingId)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class,
                () -> notificationService.getNotificationById(missingId));

        verify(notificationRepository, times(1)).findById(missingId);
        verify(notificationRepository, never()).delete(any());
    }

    @Test
    @DisplayName("Исключение должно выбрасываться для любого несуществующего id")
    void shouldThrowForAnyMissingId() {
        when(notificationRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(1L));
        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(999L));
        assertThrows(NoSuchElementException.class, () -> notificationService.getNotificationById(-1L));

        verify(notificationRepository, times(3)).findById(any());
    }
}
```

## Что здесь используется

| Элемент | Назначение |
|---|---|
| `@DisplayName` | Человекочитаемое имя теста в отчёте |
| `when(...).thenReturn(Optional.empty())` | Эмуляция «уведомление не найдено» в БД |
| `assertThrows(NoSuchElementException.class, ...)` | Проверка типа исключения — критично, т.к. именно его выбрасывает `orElseThrow()` |
| `verify(..., times(1))` | Подтверждение, что репозиторий был вызван |
| `verify(..., never()).delete(any())` | Защита от ложноположительных правок: метод удаления не должен срабатывать при ошибке поиска |
| `when(..., any()).thenReturn(...)` | Параметризованный стаб, чтобы один мок покрыл несколько «несуществующих» id |

## Покрытие сценариев

1. **`shouldThrowWhenNotificationNotFoundById`** — базовый негативный сценарий: конкретный `id=404` отсутствует → выбрасывается `NoSuchElementException`.
2. **`shouldThrowForAnyMissingId`** — параметризованная проверка: для нескольких разных «несуществующих» id (1, 999, -1) метод ведёт себя одинаково. Подтверждает, что сервис не делает случайных ветвлений по значению id.

## Зависимости

Использует `spring-boot-starter-test` из `pom.xml` проекта `spring-lab3-notifications` (JUnit 5, Mockito). Дополнительных зависимостей не требуется.


## Почему это важно

Негативные тесты фиксируют поведение «ошибочного сценария». Без них рефакторинг мог бы случайно изменить реакцию метода на отсутствующие данные (например, начать возвращать `null` или глотать исключение), и unit-тест на позитивный сценарий это не поймал бы.
