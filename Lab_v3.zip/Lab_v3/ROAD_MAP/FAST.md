1. `http://localhost:8080/hello`
2. `http://localhost:8080/goodbye`
3. `http://localhost:8080/greet?name=Иван`
4. `http://localhost:8080/notify?message=Привет&email=test@mail.ru`